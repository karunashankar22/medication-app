export type DayOfWeek = 'monday' | 'tuesday' | 'wednesday' | 'thursday' | 'friday' | 'saturday' | 'sunday';

export type MedicationTime = {
  hour: number;
  minute: number;
  id: string;
};

export type Medication = {
  id: string;
  name: string;
  dosage: string;
  instructions?: string;
  days: DayOfWeek[];
  times: MedicationTime[];
  color?: string;
  createdAt: number;
  updatedAt: number;
};

export type MedicationIntake = {
  id: string;
  medicationId: string;
  medicationName: string;
  dosage: string;
  scheduledTime: number;
  takenTime: number | null;
  status: 'taken' | 'missed' | 'scheduled';
};

export type MedicationWithNextDose = Medication & {
  nextDose?: {
    time: number;
    formattedTime: string;
  };
};