import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { Medication, MedicationTime } from '@/types/medication';
import { getMedications, saveIntake } from './storage';
import { formatTime } from './utils';
import { generateId } from './utils';

export async function initNotifications() {
  // Set notification handler
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: true,
      shouldPlaySound: true,
      shouldSetBadge: true,
    }),
  });
  
  // Request permissions
  const { status } = await Notifications.requestPermissionsAsync();
  if (status !== 'granted') {
    console.log('Notification permissions not granted');
    return false;
  }
  
  // Set notification categories/actions
  Notifications.setNotificationCategoryAsync('medication', [
    {
      identifier: 'TAKE',
      buttonTitle: 'Take Now',
      options: {
        isDestructive: false,
        isAuthenticationRequired: false,
      },
    },
    {
      identifier: 'SKIP',
      buttonTitle: 'Skip',
      options: {
        isDestructive: true,
        isAuthenticationRequired: false,
      },
    },
  ]);
  
  return true;
}

export async function scheduleMedicationNotifications(medication: Medication) {
  // Cancel existing notifications for this medication
  await cancelMedicationNotifications(medication.id);
  
  // Get next 7 days dates
  const next7Days = getNext7DayDates();
  
  // For each day that matches medication schedule
  for (const day of next7Days) {
    const dayName = getDayName(day).toLowerCase();
    
    // Skip if medication is not scheduled for this day
    if (!medication.days.includes(dayName as any)) {
      continue;
    }
    
    // Schedule notifications for each time on this day
    for (const time of medication.times) {
      const notificationDate = new Date(day);
      notificationDate.setHours(time.hour, time.minute, 0);
      
      // Skip if the time is in the past
      if (notificationDate.getTime() < Date.now()) {
        continue;
      }
      
      // Create an intake record for this scheduled dose
      const intake = {
        id: generateId(),
        medicationId: medication.id,
        medicationName: medication.name,
        dosage: medication.dosage,
        scheduledTime: notificationDate.getTime(),
        takenTime: null,
        status: 'scheduled',
      };
      
      await saveIntake(intake);
      
      // Schedule the notification
      await Notifications.scheduleNotificationAsync({
        content: {
          title: 'Medication Reminder',
          body: `Time to take ${medication.name} (${medication.dosage})`,
          data: { medicationId: medication.id, intakeId: intake.id },
          categoryIdentifier: 'medication',
        },
        trigger: {
          date: notificationDate,
        },
      });
    }
  }
}

export async function cancelMedicationNotifications(medicationId: string) {
  const scheduledNotifications = await Notifications.getAllScheduledNotificationsAsync();
  
  for (const notification of scheduledNotifications) {
    if (notification.content.data?.medicationId === medicationId) {
      await Notifications.cancelScheduledNotificationAsync(notification.identifier);
    }
  }
}

export async function rescheduleAllNotifications() {
  // Cancel all existing notifications
  await Notifications.cancelAllScheduledNotificationsAsync();
  
  // Get all medications
  const medications = await getMedications();
  
  // Reschedule for each medication
  for (const medication of medications) {
    await scheduleMedicationNotifications(medication);
  }
}

// Helper Functions
function getNext7DayDates() {
  const dates = [];
  const now = new Date();
  
  for (let i = 0; i < 7; i++) {
    const date = new Date();
    date.setDate(now.getDate() + i);
    date.setHours(0, 0, 0, 0);
    dates.push(date);
  }
  
  return dates;
}

function getDayName(date: Date) {
  const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  return days[date.getDay()];
}