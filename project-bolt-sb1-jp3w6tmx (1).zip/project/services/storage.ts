import AsyncStorage from '@react-native-async-storage/async-storage';
import { Medication, MedicationIntake } from '@/types/medication';

const STORAGE_KEYS = {
  MEDICATIONS: 'medications',
  INTAKES: 'medication_intakes',
  SETTINGS: 'app_settings',
  THEME: 'theme_preference',
};

export async function initStorage() {
  try {
    // Initialize medications if not exists
    const medications = await AsyncStorage.getItem(STORAGE_KEYS.MEDICATIONS);
    if (!medications) {
      await AsyncStorage.setItem(STORAGE_KEYS.MEDICATIONS, JSON.stringify([]));
    }
    
    // Initialize intakes if not exists
    const intakes = await AsyncStorage.getItem(STORAGE_KEYS.INTAKES);
    if (!intakes) {
      await AsyncStorage.setItem(STORAGE_KEYS.INTAKES, JSON.stringify([]));
    }
    
    // Initialize settings if not exists
    const settings = await AsyncStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!settings) {
      const defaultSettings = {
        notifications: {
          enabled: true,
          sound: true,
          vibration: true,
        },
      };
      await AsyncStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(defaultSettings));
    }
    
    return true;
  } catch (error) {
    console.error('Failed to initialize storage:', error);
    return false;
  }
}

// Medication Functions
export async function getMedications(): Promise<Medication[]> {
  try {
    const data = await AsyncStorage.getItem(STORAGE_KEYS.MEDICATIONS);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Failed to get medications:', error);
    return [];
  }
}

export async function getMedicationById(id: string): Promise<Medication | null> {
  try {
    const medications = await getMedications();
    return medications.find(med => med.id === id) || null;
  } catch (error) {
    console.error('Failed to get medication by id:', error);
    return null;
  }
}

export async function saveMedication(medication: Medication): Promise<boolean> {
  try {
    const medications = await getMedications();
    const existingIndex = medications.findIndex(med => med.id === medication.id);
    
    if (existingIndex >= 0) {
      // Update existing medication
      medications[existingIndex] = {
        ...medication,
        updatedAt: Date.now(),
      };
    } else {
      // Add new medication
      medications.push({
        ...medication,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
    }
    
    await AsyncStorage.setItem(STORAGE_KEYS.MEDICATIONS, JSON.stringify(medications));
    return true;
  } catch (error) {
    console.error('Failed to save medication:', error);
    return false;
  }
}

export async function deleteMedication(id: string): Promise<boolean> {
  try {
    const medications = await getMedications();
    const updatedMedications = medications.filter(med => med.id !== id);
    await AsyncStorage.setItem(STORAGE_KEYS.MEDICATIONS, JSON.stringify(updatedMedications));
    
    // Also delete related intakes
    const intakes = await getIntakes();
    const updatedIntakes = intakes.filter(intake => intake.medicationId !== id);
    await AsyncStorage.setItem(STORAGE_KEYS.INTAKES, JSON.stringify(updatedIntakes));
    
    return true;
  } catch (error) {
    console.error('Failed to delete medication:', error);
    return false;
  }
}

// Intake Functions
export async function getIntakes(): Promise<MedicationIntake[]> {
  try {
    const data = await AsyncStorage.getItem(STORAGE_KEYS.INTAKES);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Failed to get intakes:', error);
    return [];
  }
}

export async function getIntakesByMedicationId(medicationId: string): Promise<MedicationIntake[]> {
  try {
    const intakes = await getIntakes();
    return intakes.filter(intake => intake.medicationId === medicationId);
  } catch (error) {
    console.error('Failed to get intakes by medication id:', error);
    return [];
  }
}

export async function saveIntake(intake: MedicationIntake): Promise<boolean> {
  try {
    const intakes = await getIntakes();
    const existingIndex = intakes.findIndex(i => i.id === intake.id);
    
    if (existingIndex >= 0) {
      // Update existing intake
      intakes[existingIndex] = intake;
    } else {
      // Add new intake
      intakes.push(intake);
    }
    
    await AsyncStorage.setItem(STORAGE_KEYS.INTAKES, JSON.stringify(intakes));
    return true;
  } catch (error) {
    console.error('Failed to save intake:', error);
    return false;
  }
}

// Settings Functions
export async function getSettings() {
  try {
    const data = await AsyncStorage.getItem(STORAGE_KEYS.SETTINGS);
    return data ? JSON.parse(data) : null;
  } catch (error) {
    console.error('Failed to get settings:', error);
    return null;
  }
}

export async function saveSettings(settings: any): Promise<boolean> {
  try {
    await AsyncStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    return true;
  } catch (error) {
    console.error('Failed to save settings:', error);
    return false;
  }
}

// Theme Preference
export async function getThemePreference(): Promise<string | null> {
  try {
    return await AsyncStorage.getItem(STORAGE_KEYS.THEME);
  } catch (error) {
    console.error('Failed to get theme preference:', error);
    return null;
  }
}

export async function saveThemePreference(theme: string): Promise<boolean> {
  try {
    await AsyncStorage.setItem(STORAGE_KEYS.THEME, theme);
    return true;
  } catch (error) {
    console.error('Failed to save theme preference:', error);
    return false;
  }
}