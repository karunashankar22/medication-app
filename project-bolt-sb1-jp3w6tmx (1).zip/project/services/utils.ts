import { MedicationTime, Medication, MedicationWithNextDose, DayOfWeek } from '@/types/medication';

export function generateId(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

export function formatTime(hours: number, minutes: number): string {
  const period = hours >= 12 ? 'PM' : 'AM';
  const hour = hours % 12 || 12;
  const minute = minutes.toString().padStart(2, '0');
  return `${hour}:${minute} ${period}`;
}

export function formatTimeFromDate(date: Date): string {
  return formatTime(date.getHours(), date.getMinutes());
}

export function formatDate(date: Date): string {
  const options: Intl.DateTimeFormatOptions = { 
    weekday: 'long', 
    month: 'long', 
    day: 'numeric'
  };
  
  return date.toLocaleDateString('en-US', options);
}

export function getDayOfWeek(date: Date): DayOfWeek {
  const days: DayOfWeek[] = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'] as DayOfWeek[];
  return days[date.getDay()];
}

export function getTimeObject(date: Date): MedicationTime {
  return {
    hour: date.getHours(),
    minute: date.getMinutes(),
    id: generateId()
  };
}

export function getFormattedDaysList(days: DayOfWeek[]): string {
  if (days.length === 7) {
    return 'Every day';
  }
  
  if (days.length === 0) {
    return 'No days selected';
  }
  
  if (
    days.includes('monday') && 
    days.includes('tuesday') && 
    days.includes('wednesday') && 
    days.includes('thursday') && 
    days.includes('friday') && 
    !days.includes('saturday') && 
    !days.includes('sunday')
  ) {
    return 'Weekdays';
  }
  
  if (
    !days.includes('monday') && 
    !days.includes('tuesday') && 
    !days.includes('wednesday') && 
    !days.includes('thursday') && 
    !days.includes('friday') && 
    days.includes('saturday') && 
    days.includes('sunday')
  ) {
    return 'Weekends';
  }
  
  // Format individual days
  const dayNames = {
    monday: 'Mon',
    tuesday: 'Tue',
    wednesday: 'Wed',
    thursday: 'Thu',
    friday: 'Fri',
    saturday: 'Sat',
    sunday: 'Sun'
  };
  
  return days.map(day => dayNames[day]).join(', ');
}

export function addNextDoseInfo(medications: Medication[]): MedicationWithNextDose[] {
  const now = new Date();
  const today = getDayOfWeek(now);
  const currentHour = now.getHours();
  const currentMinute = now.getMinutes();
  
  return medications.map(medication => {
    // Check if medication is scheduled for today
    const isTodayScheduled = medication.days.includes(today);
    
    if (isTodayScheduled) {
      // Find the next dose time for today
      const todayTimes = medication.times
        .filter(time => (time.hour > currentHour) || (time.hour === currentHour && time.minute > currentMinute))
        .sort((a, b) => (a.hour - b.hour) || (a.minute - b.minute));
      
      if (todayTimes.length > 0) {
        const nextTime = todayTimes[0];
        const nextDoseDate = new Date();
        nextDoseDate.setHours(nextTime.hour, nextTime.minute, 0, 0);
        
        return {
          ...medication,
          nextDose: {
            time: nextDoseDate.getTime(),
            formattedTime: formatTime(nextTime.hour, nextTime.minute)
          }
        };
      }
    }
    
    // Find the next scheduled day
    const daysOfWeek: DayOfWeek[] = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const todayIndex = daysOfWeek.indexOf(today);
    
    let nextDayIndex = -1;
    for (let i = 1; i <= 7; i++) {
      const checkIndex = (todayIndex + i) % 7;
      if (medication.days.includes(daysOfWeek[checkIndex])) {
        nextDayIndex = checkIndex;
        break;
      }
    }
    
    if (nextDayIndex !== -1) {
      const daysToAdd = (nextDayIndex - todayIndex + 7) % 7;
      const nextDate = new Date();
      nextDate.setDate(now.getDate() + daysToAdd);
      
      // Get the earliest time for that day
      const earliestTime = medication.times.sort((a, b) => (a.hour - b.hour) || (a.minute - b.minute))[0];
      
      if (earliestTime) {
        nextDate.setHours(earliestTime.hour, earliestTime.minute, 0, 0);
        
        return {
          ...medication,
          nextDose: {
            time: nextDate.getTime(),
            formattedTime: `${formatTime(earliestTime.hour, earliestTime.minute)} (${daysOfWeek[nextDayIndex].charAt(0).toUpperCase() + daysOfWeek[nextDayIndex].slice(1).slice(0, 2)})`
          }
        };
      }
    }
    
    // No next dose found
    return medication;
  });
}