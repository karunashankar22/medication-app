import React from 'react';
import { StyleSheet, Text, View, TouchableOpacity, useColorScheme } from 'react-native';
import { useRouter } from 'expo-router';
import { CirclePlus as PlusCircle } from 'lucide-react-native';
import Colors from '@/constants/Colors';

type EmptyStateProps = {
  title: string;
  message: string;
  actionLabel?: string;
  actionRoute?: string;
  icon?: React.ReactNode;
};

export default function EmptyState({
  title,
  message,
  actionLabel = 'Add Medication',
  actionRoute = '/medication/add',
  icon
}: EmptyStateProps) {
  const router = useRouter();
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];
  
  return (
    <View style={styles.container}>
      {icon || (
        <View style={[styles.iconContainer, { backgroundColor: colors.pill }]}>
          <PlusCircle size={60} color={colors.tint} />
        </View>
      )}
      <Text style={[styles.title, { color: colors.text }]}>{title}</Text>
      <Text style={[styles.message, { color: colors.tabIconDefault }]}>{message}</Text>
      
      {actionRoute && (
        <TouchableOpacity
          style={[styles.button, { backgroundColor: colors.tint }]}
          onPress={() => router.push(actionRoute)}
        >
          <Text style={styles.buttonText}>{actionLabel}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  iconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 22,
    fontFamily: 'SF-Pro-Display-Bold',
    marginBottom: 8,
    textAlign: 'center',
  },
  message: {
    fontSize: 16,
    fontFamily: 'SF-Pro-Text-Regular',
    textAlign: 'center',
    marginBottom: 32,
    lineHeight: 22,
  },
  button: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 25,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
    fontFamily: 'SF-Pro-Text-Medium',
  },
});