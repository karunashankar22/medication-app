import React from 'react';
import { StyleSheet, Text, View, TouchableOpacity, useColorScheme } from 'react-native';
import { Check, Clock } from 'lucide-react-native';
import { MedicationWithNextDose } from '@/types/medication';
import { useRouter } from 'expo-router';
import Colors from '@/constants/Colors';
import { getFormattedDaysList } from '@/services/utils';

type MedicationCardProps = {
  medication: MedicationWithNextDose;
  onMarkTaken?: () => void;
  showActions?: boolean;
};

export default function MedicationCard({ medication, onMarkTaken, showActions = true }: MedicationCardProps) {
  const router = useRouter();
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];
  
  const handlePress = () => {
    router.push(`/medication/${medication.id}`);
  };
  
  const handleMarkTaken = (e: any) => {
    e.stopPropagation();
    if (onMarkTaken) onMarkTaken();
  };
  
  // Define a list of colors to use for the pill indicator
  const pillColors = ['#4A90E2', '#5856D6', '#FF2D55', '#FF9500', '#34C759', '#AF52DE'];
  const pillColor = medication.color || pillColors[Math.floor(Math.random() * pillColors.length)];
  
  return (
    <TouchableOpacity 
      style={[
        styles.card, 
        { backgroundColor: colors.cardBackground, borderColor: colors.border }
      ]} 
      onPress={handlePress}
      activeOpacity={0.7}
    >
      <View style={styles.content}>
        <View style={[styles.pillIndicator, { backgroundColor: pillColor }]} />
        <View style={styles.details}>
          <Text style={[styles.name, { color: colors.text }]}>{medication.name}</Text>
          <Text style={[styles.dosage, { color: colors.text }]}>{medication.dosage}</Text>
          <Text style={[styles.schedule, { color: colors.tabIconDefault }]}>
            {getFormattedDaysList(medication.days)}
          </Text>
        </View>
        
        {medication.nextDose && (
          <View style={styles.nextDose}>
            <View style={styles.timeContainer}>
              <Clock size={14} color={colors.tabIconDefault} style={styles.clockIcon} />
              <Text style={[styles.nextDoseTime, { color: colors.tabIconDefault }]}>
                {medication.nextDose.formattedTime}
              </Text>
            </View>
            
            {showActions && onMarkTaken && (
              <TouchableOpacity 
                style={[styles.takePillButton, { backgroundColor: colors.tint }]} 
                onPress={handleMarkTaken}
              >
                <Check size={18} color="#FFF" />
                <Text style={styles.takePillText}>Take</Text>
              </TouchableOpacity>
            )}
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 12,
    marginBottom: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    borderWidth: 1,
  },
  content: {
    flexDirection: 'row',
  },
  pillIndicator: {
    width: 6,
    borderRadius: 3,
    marginRight: 12,
  },
  details: {
    flex: 1,
  },
  name: {
    fontSize: 17,
    fontFamily: 'SF-Pro-Display-Semibold',
    marginBottom: 4,
  },
  dosage: {
    fontSize: 15,
    fontFamily: 'SF-Pro-Text-Regular',
    marginBottom: 4,
  },
  schedule: {
    fontSize: 13,
    fontFamily: 'SF-Pro-Text-Regular',
  },
  nextDose: {
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  timeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  clockIcon: {
    marginRight: 4,
  },
  nextDoseTime: {
    fontSize: 13,
    fontFamily: 'SF-Pro-Text-Medium',
  },
  takePillButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  takePillText: {
    color: '#FFF',
    fontSize: 14,
    fontFamily: 'SF-Pro-Text-Medium',
    marginLeft: 4,
  },
});