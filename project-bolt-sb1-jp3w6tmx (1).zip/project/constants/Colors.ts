const tintColorLight = '#4A90E2';
const tintColorDark = '#6AB0FF';

export default {
  light: {
    text: '#000000',
    background: '#F8F8F8',
    tint: tintColorLight,
    tabIconDefault: '#C7C7CC',
    tabIconSelected: tintColorLight,
    cardBackground: '#FFFFFF',
    success: '#34C759',
    warning: '#FF9500',
    error: '#FF3B30',
    border: '#E5E5EA',
    pill: '#F2F2F7',
  },
  dark: {
    text: '#FFFFFF',
    background: '#121212',
    tint: tintColorDark,
    tabIconDefault: '#6E6E73',
    tabIconSelected: tintColorDark,
    cardBackground: '#1C1C1E',
    success: '#30D158',
    warning: '#FF9F0A',
    error: '#FF453A',
    border: '#38383A',
    pill: '#2C2C2E',
  },
};