import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, FlatList, TouchableOpacity, useColorScheme, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Plus } from 'lucide-react-native';
import Colors from '@/constants/Colors';
import { getMedications } from '@/services/storage';
import { addNextDoseInfo } from '@/services/utils';
import { MedicationWithNextDose } from '@/types/medication';
import MedicationCard from '@/components/MedicationCard';
import EmptyState from '@/components/EmptyState';

export default function MedicationsScreen() {
  const router = useRouter();
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];
  
  const [medications, setMedications] = useState<MedicationWithNextDose[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  
  useEffect(() => {
    loadMedications();
  }, []);
  
  const loadMedications = async () => {
    try {
      const meds = await getMedications();
      const withNextDose = addNextDoseInfo(meds);
      
      // Sort alphabetically by name
      const sorted = withNextDose.sort((a, b) => a.name.localeCompare(b.name));
      
      setMedications(sorted);
    } catch (error) {
      console.error('Failed to load medications:', error);
    }
  };
  
  const handleRefresh = async () => {
    setRefreshing(true);
    await loadMedications();
    setRefreshing(false);
  };
  
  const renderItem = ({ item }: { item: MedicationWithNextDose }) => {
    return <MedicationCard medication={item} showActions={false} />;
  };
  
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.text }]}>Medications</Text>
        <TouchableOpacity 
          style={[styles.addButton, { backgroundColor: colors.tint }]}
          onPress={() => router.push('/medication/add')}
        >
          <Plus size={20} color="#FFF" />
          <Text style={styles.addButtonText}>Add</Text>
        </TouchableOpacity>
      </View>
      
      {medications.length > 0 ? (
        <FlatList
          data={medications}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />
          }
        />
      ) : (
        <EmptyState
          title="No Medications"
          message="You haven't added any medications yet. Add your first medication to get started."
          actionLabel="Add Medication"
          actionRoute="/medication/add"
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
  },
  title: {
    fontSize: 28,
    fontFamily: 'SF-Pro-Display-Bold',
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  addButtonText: {
    color: '#FFF',
    marginLeft: 4,
    fontSize: 15,
    fontFamily: 'SF-Pro-Text-Medium',
  },
  list: {
    padding: 20,
  },
});