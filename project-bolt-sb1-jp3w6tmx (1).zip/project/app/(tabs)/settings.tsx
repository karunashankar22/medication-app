import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, Switch, useColorScheme, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Colors from '@/constants/Colors';
import { getSettings, saveSettings } from '@/services/storage';
import { rescheduleAllNotifications } from '@/services/notifications';
import { useTheme } from '@/context/ThemeContext';
import { Bell, Moon, Sun, Smartphone, RefreshCw } from 'lucide-react-native';

export default function SettingsScreen() {
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];
  const { theme, setTheme } = useTheme();
  
  const [settings, setSettings] = useState({
    notifications: {
      enabled: true,
      sound: true,
      vibration: true,
    },
  });
  
  useEffect(() => {
    loadSettings();
  }, []);
  
  const loadSettings = async () => {
    try {
      const savedSettings = await getSettings();
      if (savedSettings) {
        setSettings(savedSettings);
      }
    } catch (error) {
      console.error('Failed to load settings:', error);
    }
  };
  
  const handleSettingChange = async (section: string, setting: string, value: boolean) => {
    try {
      const updatedSettings = {
        ...settings,
        [section]: {
          ...settings[section as keyof typeof settings],
          [setting]: value,
        },
      };
      
      setSettings(updatedSettings);
      await saveSettings(updatedSettings);
      
      // If we're enabling/disabling notifications, reschedule them
      if (section === 'notifications' && setting === 'enabled') {
        if (value) {
          await rescheduleAllNotifications();
        }
      }
    } catch (error) {
      console.error('Failed to save setting:', error);
    }
  };
  
  const handleRescheduleNotifications = async () => {
    try {
      await rescheduleAllNotifications();
      Alert.alert(
        'Success',
        'All medication notifications have been rescheduled.',
        [{ text: 'OK' }]
      );
    } catch (error) {
      console.error('Failed to reschedule notifications:', error);
      Alert.alert(
        'Error',
        'Failed to reschedule notifications. Please try again.',
        [{ text: 'OK' }]
      );
    }
  };
  
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.text }]}>Settings</Text>
      </View>
      
      <ScrollView style={styles.content}>
        <View style={[styles.section, { backgroundColor: colors.cardBackground, borderColor: colors.border }]}>
          <View style={styles.sectionHeader}>
            <Bell size={20} color={colors.tint} />
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Notifications</Text>
          </View>
          
          <View style={[styles.settingItem, { borderColor: colors.border }]}>
            <Text style={[styles.settingLabel, { color: colors.text }]}>Enable Notifications</Text>
            <Switch
              value={settings.notifications.enabled}
              onValueChange={(value) => handleSettingChange('notifications', 'enabled', value)}
              trackColor={{ false: '#767577', true: colors.success }}
              thumbColor="#FFFFFF"
            />
          </View>
          
          <View style={[styles.settingItem, { borderColor: colors.border }]}>
            <Text style={[styles.settingLabel, { color: colors.text }]}>Sound</Text>
            <Switch
              value={settings.notifications.sound}
              onValueChange={(value) => handleSettingChange('notifications', 'sound', value)}
              trackColor={{ false: '#767577', true: colors.success }}
              thumbColor="#FFFFFF"
              disabled={!settings.notifications.enabled}
            />
          </View>
          
          <View style={styles.settingItem}>
            <Text style={[styles.settingLabel, { color: colors.text }]}>Vibration</Text>
            <Switch
              value={settings.notifications.vibration}
              onValueChange={(value) => handleSettingChange('notifications', 'vibration', value)}
              trackColor={{ false: '#767577', true: colors.success }}
              thumbColor="#FFFFFF"
              disabled={!settings.notifications.enabled}
            />
          </View>
        </View>
        
        <View style={[styles.section, { backgroundColor: colors.cardBackground, borderColor: colors.border }]}>
          <View style={styles.sectionHeader}>
            <Smartphone size={20} color={colors.tint} />
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Appearance</Text>
          </View>
          
          <TouchableOpacity 
            style={[styles.settingItem, { borderColor: colors.border }]}
            onPress={() => setTheme('light')}
          >
            <View style={styles.themeOption}>
              <Sun size={20} color={colors.text} />
              <Text style={[styles.settingLabel, { color: colors.text, marginLeft: 12 }]}>Light Mode</Text>
            </View>
            {theme === 'light' && (
              <View style={[styles.selectedIndicator, { backgroundColor: colors.tint }]} />
            )}
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.settingItem, { borderColor: colors.border }]}
            onPress={() => setTheme('dark')}
          >
            <View style={styles.themeOption}>
              <Moon size={20} color={colors.text} />
              <Text style={[styles.settingLabel, { color: colors.text, marginLeft: 12 }]}>Dark Mode</Text>
            </View>
            {theme === 'dark' && (
              <View style={[styles.selectedIndicator, { backgroundColor: colors.tint }]} />
            )}
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.settingItem}
            onPress={() => setTheme('system')}
          >
            <View style={styles.themeOption}>
              <Smartphone size={20} color={colors.text} />
              <Text style={[styles.settingLabel, { color: colors.text, marginLeft: 12 }]}>System Default</Text>
            </View>
            {theme === 'system' && (
              <View style={[styles.selectedIndicator, { backgroundColor: colors.tint }]} />
            )}
          </TouchableOpacity>
        </View>
        
        <View style={[styles.section, { backgroundColor: colors.cardBackground, borderColor: colors.border }]}>
          <View style={styles.sectionHeader}>
            <RefreshCw size={20} color={colors.tint} />
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Maintenance</Text>
          </View>
          
          <TouchableOpacity 
            style={styles.settingItem}
            onPress={handleRescheduleNotifications}
          >
            <Text style={[styles.settingLabel, { color: colors.text }]}>Reschedule All Notifications</Text>
          </TouchableOpacity>
        </View>
        
        <Text style={[styles.version, { color: colors.tabIconDefault }]}>Medication Reminder v1.0.0</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
  },
  title: {
    fontSize: 28,
    fontFamily: 'SF-Pro-Display-Bold',
  },
  content: {
    flex: 1,
  },
  section: {
    marginHorizontal: 20,
    marginBottom: 20,
    borderRadius: 12,
    borderWidth: 1,
    overflow: 'hidden',
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  sectionTitle: {
    fontSize: 17,
    fontFamily: 'SF-Pro-Display-Semibold',
    marginLeft: 10,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderTopWidth: 1,
  },
  settingLabel: {
    fontSize: 16,
    fontFamily: 'SF-Pro-Text-Regular',
  },
  themeOption: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  selectedIndicator: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  version: {
    textAlign: 'center',
    fontSize: 14,
    fontFamily: 'SF-Pro-Text-Regular',
    marginVertical: 20,
  },
});