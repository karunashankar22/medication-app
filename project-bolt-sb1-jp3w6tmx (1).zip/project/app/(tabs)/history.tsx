import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, SectionList, useColorScheme, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Colors from '@/constants/Colors';
import { getIntakes } from '@/services/storage';
import { MedicationIntake } from '@/types/medication';
import { formatTimeFromDate } from '@/services/utils';
import { Check, X } from 'lucide-react-native';
import EmptyState from '@/components/EmptyState';

type Section = {
  title: string;
  data: MedicationIntake[];
};

export default function HistoryScreen() {
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];
  
  const [sections, setSections] = useState<Section[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  
  useEffect(() => {
    loadHistory();
  }, []);
  
  const loadHistory = async () => {
    try {
      const intakes = await getIntakes();
      
      // Filter out scheduled intakes (those that haven't been taken or missed yet)
      const completedIntakes = intakes.filter(intake => intake.status !== 'scheduled');
      
      if (completedIntakes.length === 0) {
        setSections([]);
        return;
      }
      
      // Sort by scheduledTime, most recent first
      const sortedIntakes = completedIntakes.sort((a, b) => b.scheduledTime - a.scheduledTime);
      
      // Group by date
      const groupedByDate: Record<string, MedicationIntake[]> = {};
      
      for (const intake of sortedIntakes) {
        const date = new Date(intake.scheduledTime);
        const dateString = `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
        
        if (!groupedByDate[dateString]) {
          groupedByDate[dateString] = [];
        }
        
        groupedByDate[dateString].push(intake);
      }
      
      // Convert to sections
      const newSections: Section[] = Object.keys(groupedByDate).map(dateString => {
        const date = new Date(dateString);
        const today = new Date();
        const yesterday = new Date();
        yesterday.setDate(today.getDate() - 1);
        
        let title;
        
        if (date.toDateString() === today.toDateString()) {
          title = 'Today';
        } else if (date.toDateString() === yesterday.toDateString()) {
          title = 'Yesterday';
        } else {
          const options: Intl.DateTimeFormatOptions = { month: 'long', day: 'numeric', year: 'numeric' };
          title = date.toLocaleDateString('en-US', options);
        }
        
        return {
          title,
          data: groupedByDate[dateString]
        };
      });
      
      setSections(newSections);
    } catch (error) {
      console.error('Failed to load history:', error);
    }
  };
  
  const handleRefresh = async () => {
    setRefreshing(true);
    await loadHistory();
    setRefreshing(false);
  };
  
  const renderItem = ({ item }: { item: MedicationIntake }) => {
    const scheduledTime = new Date(item.scheduledTime);
    const takenTime = item.takenTime ? new Date(item.takenTime) : null;
    
    return (
      <View style={[styles.itemContainer, { backgroundColor: colors.cardBackground, borderColor: colors.border }]}>
        <View style={styles.itemContent}>
          <View style={styles.medicationInfo}>
            <Text style={[styles.medicationName, { color: colors.text }]}>{item.medicationName}</Text>
            <Text style={[styles.dosage, { color: colors.tabIconDefault }]}>{item.dosage}</Text>
            <Text style={[styles.time, { color: colors.tabIconDefault }]}>
              Scheduled: {formatTimeFromDate(scheduledTime)}
            </Text>
          </View>
          
          <View style={[
            styles.statusIndicator, 
            { backgroundColor: item.status === 'taken' ? colors.success : colors.error }
          ]}>
            {item.status === 'taken' ? (
              <Check size={16} color="#FFF" />
            ) : (
              <X size={16} color="#FFF" />
            )}
          </View>
        </View>
        
        {item.status === 'taken' && takenTime && (
          <View style={styles.takenTimeContainer}>
            <Text style={[styles.takenTime, { color: colors.tabIconDefault }]}>
              Taken at {formatTimeFromDate(takenTime)}
            </Text>
          </View>
        )}
      </View>
    );
  };
  
  const renderSectionHeader = ({ section }: { section: Section }) => (
    <View style={[styles.sectionHeader, { backgroundColor: colors.background }]}>
      <Text style={[styles.sectionTitle, { color: colors.text }]}>{section.title}</Text>
    </View>
  );
  
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.text }]}>History</Text>
      </View>
      
      {sections.length > 0 ? (
        <SectionList
          sections={sections}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          renderSectionHeader={renderSectionHeader}
          contentContainerStyle={styles.list}
          stickySectionHeadersEnabled={true}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />
          }
        />
      ) : (
        <EmptyState
          title="No History Yet"
          message="Your medication history will appear here once you start tracking your medications."
          actionLabel="Add Medication"
          actionRoute="/medication/add"
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
  },
  title: {
    fontSize: 28,
    fontFamily: 'SF-Pro-Display-Bold',
  },
  list: {
    paddingBottom: 20,
  },
  sectionHeader: {
    paddingHorizontal: 20,
    paddingVertical: 8,
  },
  sectionTitle: {
    fontSize: 17,
    fontFamily: 'SF-Pro-Display-Semibold',
  },
  itemContainer: {
    marginHorizontal: 20,
    marginVertical: 6,
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
  },
  itemContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  medicationInfo: {
    flex: 1,
  },
  medicationName: {
    fontSize: 16,
    fontFamily: 'SF-Pro-Text-Medium',
    marginBottom: 4,
  },
  dosage: {
    fontSize: 14,
    fontFamily: 'SF-Pro-Text-Regular',
    marginBottom: 4,
  },
  time: {
    fontSize: 13,
    fontFamily: 'SF-Pro-Text-Regular',
  },
  statusIndicator: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
  },
  takenTimeContainer: {
    marginTop: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#E5E5EA',
  },
  takenTime: {
    fontSize: 13,
    fontFamily: 'SF-Pro-Text-Regular',
  },
});