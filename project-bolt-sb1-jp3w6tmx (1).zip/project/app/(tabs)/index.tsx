import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, FlatList, useColorScheme, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Colors from '@/constants/Colors';
import { getMedications, saveIntake } from '@/services/storage';
import { addNextDoseInfo, formatDate, generateId } from '@/services/utils';
import { MedicationWithNextDose } from '@/types/medication';
import MedicationCard from '@/components/MedicationCard';
import EmptyState from '@/components/EmptyState';
import * as Haptics from 'expo-haptics';

export default function HomeScreen() {
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];
  
  const [medications, setMedications] = useState<MedicationWithNextDose[]>([]);
  const [today, setToday] = useState<Date>(new Date());
  const [refreshing, setRefreshing] = useState(false);
  
  useEffect(() => {
    loadMedications();
  }, []);
  
  const loadMedications = async () => {
    try {
      const meds = await getMedications();
      const withNextDose = addNextDoseInfo(meds);
      
      // Sort by next dose time
      const sorted = withNextDose.sort((a, b) => {
        if (!a.nextDose && !b.nextDose) return 0;
        if (!a.nextDose) return 1;
        if (!b.nextDose) return -1;
        return a.nextDose.time - b.nextDose.time;
      });
      
      setMedications(sorted);
    } catch (error) {
      console.error('Failed to load medications:', error);
    }
  };
  
  const handleRefresh = async () => {
    setRefreshing(true);
    await loadMedications();
    setRefreshing(false);
  };
  
  const handleMarkTaken = async (medication: MedicationWithNextDose) => {
    if (!medication.nextDose) return;
    
    // Trigger haptic feedback
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    
    try {
      // Create an intake record
      const intake = {
        id: generateId(),
        medicationId: medication.id,
        medicationName: medication.name,
        dosage: medication.dosage,
        scheduledTime: medication.nextDose.time,
        takenTime: Date.now(),
        status: 'taken',
      };
      
      await saveIntake(intake);
      
      // Refresh medications to update next dose
      await loadMedications();
    } catch (error) {
      console.error('Failed to mark medication as taken:', error);
    }
  };
  
  const renderItem = ({ item }: { item: MedicationWithNextDose }) => {
    // Only show medications with a next dose
    if (!item.nextDose) return null;
    
    return (
      <MedicationCard
        medication={item}
        onMarkTaken={() => handleMarkTaken(item)}
      />
    );
  };
  
  // Filter medications that have next dose scheduled for today
  const todayMedications = medications.filter(med => {
    if (!med.nextDose) return false;
    
    const nextDoseDate = new Date(med.nextDose.time);
    const today = new Date();
    
    return (
      nextDoseDate.getDate() === today.getDate() &&
      nextDoseDate.getMonth() === today.getMonth() &&
      nextDoseDate.getFullYear() === today.getFullYear()
    );
  });
  
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <View style={styles.header}>
        <Text style={[styles.date, { color: colors.tabIconDefault }]}>
          {formatDate(today)}
        </Text>
        <Text style={[styles.title, { color: colors.text }]}>Today's Medications</Text>
      </View>
      
      {todayMedications.length > 0 ? (
        <FlatList
          data={todayMedications}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />
          }
        />
      ) : (
        <EmptyState
          title="No Medications Today"
          message="You don't have any medications scheduled for today. Add a medication to get started."
          actionLabel="Add Medication"
          actionRoute="/medication/add"
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
  },
  date: {
    fontSize: 14,
    fontFamily: 'SF-Pro-Text-Medium',
    marginBottom: 8,
  },
  title: {
    fontSize: 28,
    fontFamily: 'SF-Pro-Display-Bold',
    marginBottom: 8,
  },
  list: {
    padding: 20,
  },
});