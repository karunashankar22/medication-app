import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, ScrollView, Alert, useColorScheme } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import Colors from '@/constants/Colors';
import { getMedicationById, deleteMedication, getIntakesByMedicationId } from '@/services/storage';
import { cancelMedicationNotifications } from '@/services/notifications';
import { Medication, MedicationIntake } from '@/types/medication';
import { formatTime, getFormattedDaysList } from '@/services/utils';
import { Pencil, Trash2, Clock, Calendar, AlarmClock, FileText } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';

export default function MedicationDetailsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];
  
  const [medication, setMedication] = useState<Medication | null>(null);
  const [intakes, setIntakes] = useState<MedicationIntake[]>([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    if (!id) return;
    
    const loadMedication = async () => {
      try {
        const med = await getMedicationById(id);
        setMedication(med);
        
        // Load intake history
        const medIntakes = await getIntakesByMedicationId(id);
        setIntakes(medIntakes.filter(intake => intake.status !== 'scheduled'));
        
      } catch (error) {
        console.error('Error loading medication:', error);
      } finally {
        setLoading(false);
      }
    };
    
    loadMedication();
  }, [id]);
  
  const handleEdit = () => {
    if (medication) {
      router.push(`/medication/edit/${medication.id}`);
    }
  };
  
  const handleDelete = () => {
    Alert.alert(
      'Delete Medication',
      `Are you sure you want to delete ${medication?.name}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            if (medication) {
              try {
                // Cancel notifications
                await cancelMedicationNotifications(medication.id);
                
                // Delete from storage
                const success = await deleteMedication(medication.id);
                
                if (success) {
                  // Haptic feedback
                  Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                  
                  // Navigate back
                  router.back();
                } else {
                  Alert.alert('Error', 'Failed to delete medication');
                }
              } catch (error) {
                console.error('Error deleting medication:', error);
                Alert.alert('Error', 'An unexpected error occurred');
              }
            }
          },
        },
      ]
    );
  };
  
  if (loading) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <Text style={[styles.loadingText, { color: colors.text }]}>Loading...</Text>
      </View>
    );
  }
  
  if (!medication) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <Text style={[styles.errorText, { color: colors.error }]}>Medication not found</Text>
      </View>
    );
  }
  
  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <View style={[styles.nameContainer, { backgroundColor: medication.color || colors.tint }]}>
          <Text style={styles.nameText}>{medication.name}</Text>
          <Text style={styles.dosageText}>{medication.dosage}</Text>
        </View>
        
        <View style={styles.actions}>
          <TouchableOpacity 
            style={[styles.actionButton, { backgroundColor: colors.pill }]} 
            onPress={handleEdit}
          >
            <Pencil size={20} color={colors.text} />
            <Text style={[styles.actionText, { color: colors.text }]}>Edit</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.actionButton, { backgroundColor: colors.error }]} 
            onPress={handleDelete}
          >
            <Trash2 size={20} color="#FFF" />
            <Text style={[styles.actionText, { color: '#FFF' }]}>Delete</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.detailsContainer}>
        <View style={[styles.detailsCard, { backgroundColor: colors.cardBackground, borderColor: colors.border }]}>
          <View style={styles.detailsRow}>
            <Calendar size={20} color={colors.tint} />
            <Text style={[styles.detailsLabel, { color: colors.text }]}>Schedule:</Text>
            <Text style={[styles.detailsValue, { color: colors.text }]}>
              {getFormattedDaysList(medication.days)}
            </Text>
          </View>
          
          <View style={styles.detailsRow}>
            <Clock size={20} color={colors.tint} />
            <Text style={[styles.detailsLabel, { color: colors.text }]}>Times:</Text>
            <View style={styles.timesContainer}>
              {medication.times
                .sort((a, b) => (a.hour * 60 + a.minute) - (b.hour * 60 + b.minute))
                .map((time, index) => (
                  <Text key={time.id} style={[styles.timeValue, { color: colors.text }]}>
                    {formatTime(time.hour, time.minute)}
                    {index < medication.times.length - 1 ? ', ' : ''}
                  </Text>
                ))}
            </View>
          </View>
          
          {medication.instructions && (
            <View style={styles.detailsRow}>
              <FileText size={20} color={colors.tint} />
              <Text style={[styles.detailsLabel, { color: colors.text }]}>Instructions:</Text>
              <Text style={[styles.detailsValue, { color: colors.text }]}>
                {medication.instructions}
              </Text>
            </View>
          )}
        </View>
        
        <View style={styles.sectionHeader}>
          <AlarmClock size={20} color={colors.tint} />
          <Text style={[styles.sectionHeaderText, { color: colors.text }]}>Recent Activity</Text>
        </View>
        
        {intakes.length > 0 ? (
          <View style={styles.intakesList}>
            {intakes
              .sort((a, b) => b.scheduledTime - a.scheduledTime)
              .slice(0, 5)
              .map(intake => {
                const scheduledTime = new Date(intake.scheduledTime);
                const takenTime = intake.takenTime ? new Date(intake.takenTime) : null;
                
                return (
                  <View 
                    key={intake.id}
                    style={[
                      styles.intakeItem, 
                      { backgroundColor: colors.cardBackground, borderColor: colors.border }
                    ]}
                  >
                    <View style={styles.intakeDetails}>
                      <Text style={[styles.intakeDate, { color: colors.text }]}>
                        {scheduledTime.toLocaleDateString('en-US', { 
                          weekday: 'short', 
                          month: 'short', 
                          day: 'numeric' 
                        })}
                      </Text>
                      <Text style={[styles.intakeTime, { color: colors.tabIconDefault }]}>
                        Scheduled: {scheduledTime.toLocaleTimeString('en-US', { 
                          hour: 'numeric', 
                          minute: '2-digit',
                          hour12: true 
                        })}
                      </Text>
                      {takenTime && (
                        <Text style={[styles.intakeTime, { color: colors.tabIconDefault }]}>
                          Taken: {takenTime.toLocaleTimeString('en-US', { 
                            hour: 'numeric', 
                            minute: '2-digit',
                            hour12: true 
                          })}
                        </Text>
                      )}
                    </View>
                    
                    <View style={[
                      styles.intakeStatus,
                      { 
                        backgroundColor: intake.status === 'taken' ? colors.success : colors.error
                      }
                    ]}>
                      <Text style={styles.intakeStatusText}>
                        {intake.status === 'taken' ? 'Taken' : 'Missed'}
                      </Text>
                    </View>
                  </View>
                );
              })}
          </View>
        ) : (
          <View style={[styles.emptyIntakes, { backgroundColor: colors.pill }]}>
            <Text style={[styles.emptyIntakesText, { color: colors.tabIconDefault }]}>
              No medication history available yet
            </Text>
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingText: {
    textAlign: 'center',
    marginTop: 20,
    fontSize: 16,
  },
  errorText: {
    textAlign: 'center',
    marginTop: 20,
    fontSize: 16,
  },
  header: {
    marginBottom: 20,
  },
  nameContainer: {
    padding: 24,
    alignItems: 'center',
  },
  nameText: {
    fontSize: 24,
    fontFamily: 'SF-Pro-Display-Bold',
    color: '#FFF',
    marginBottom: 4,
  },
  dosageText: {
    fontSize: 18,
    fontFamily: 'SF-Pro-Text-Regular',
    color: '#FFF',
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: -20,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    marginHorizontal: 8,
  },
  actionText: {
    fontSize: 15,
    fontFamily: 'SF-Pro-Text-Medium',
    marginLeft: 8,
  },
  detailsContainer: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  detailsCard: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    borderWidth: 1,
  },
  detailsRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  detailsLabel: {
    fontSize: 16,
    fontFamily: 'SF-Pro-Text-Medium',
    marginLeft: 12,
    marginRight: 8,
  },
  detailsValue: {
    fontSize: 16,
    fontFamily: 'SF-Pro-Text-Regular',
    flex: 1,
  },
  timesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    flex: 1,
  },
  timeValue: {
    fontSize: 16,
    fontFamily: 'SF-Pro-Text-Regular',
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionHeaderText: {
    fontSize: 18,
    fontFamily: 'SF-Pro-Display-Semibold',
    marginLeft: 8,
  },
  intakesList: {
    marginBottom: 20,
  },
  intakeItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
  },
  intakeDetails: {
    flex: 1,
  },
  intakeDate: {
    fontSize: 16,
    fontFamily: 'SF-Pro-Text-Medium',
    marginBottom: 4,
  },
  intakeTime: {
    fontSize: 14,
    fontFamily: 'SF-Pro-Text-Regular',
  },
  intakeStatus: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  intakeStatusText: {
    color: '#FFF',
    fontSize: 14,
    fontFamily: 'SF-Pro-Text-Medium',
  },
  emptyIntakes: {
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  emptyIntakesText: {
    fontSize: 15,
    fontFamily: 'SF-Pro-Text-Regular',
    textAlign: 'center',
  },
});