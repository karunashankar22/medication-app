import React, { useState } from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  TextInput, 
  TouchableOpacity, 
  ScrollView, 
  useColorScheme,
  Alert
} from 'react-native';
import { useRouter } from 'expo-router';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import Colors from '@/constants/Colors';
import { saveMedication } from '@/services/storage';
import { scheduleMedicationNotifications } from '@/services/notifications';
import { DayOfWeek, MedicationTime } from '@/types/medication';
import { generateId, getTimeObject, formatTime } from '@/services/utils';
import { Plus, Trash, Check } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';

const DAYS_OF_WEEK: { label: string; value: DayOfWeek }[] = [
  { label: 'Mon', value: 'monday' },
  { label: 'Tue', value: 'tuesday' },
  { label: 'Wed', value: 'wednesday' },
  { label: 'Thu', value: 'thursday' },
  { label: 'Fri', value: 'friday' },
  { label: 'Sat', value: 'saturday' },
  { label: 'Sun', value: 'sunday' },
];

// Color options for medications
const COLOR_OPTIONS = [
  '#4A90E2', // Blue
  '#5856D6', // Purple
  '#FF2D55', // Pink
  '#FF9500', // Orange
  '#34C759', // Green
  '#AF52DE', // Lavender
];

export default function AddMedicationScreen() {
  const router = useRouter();
  const colorScheme = useColorScheme() || 'light';
  const colors = Colors[colorScheme];
  
  const [name, setName] = useState('');
  const [dosage, setDosage] = useState('');
  const [instructions, setInstructions] = useState('');
  const [selectedDays, setSelectedDays] = useState<DayOfWeek[]>([]);
  const [times, setTimes] = useState<MedicationTime[]>([]);
  const [isTimePickerVisible, setTimePickerVisible] = useState(false);
  const [editingTimeId, setEditingTimeId] = useState<string | null>(null);
  const [selectedColor, setSelectedColor] = useState(COLOR_OPTIONS[0]);
  
  const toggleDay = (day: DayOfWeek) => {
    if (selectedDays.includes(day)) {
      setSelectedDays(selectedDays.filter(d => d !== day));
    } else {
      setSelectedDays([...selectedDays, day]);
    }
    
    // Haptic feedback
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };
  
  const showTimePicker = (timeId?: string) => {
    setEditingTimeId(timeId || null);
    setTimePickerVisible(true);
  };
  
  const hideTimePicker = () => {
    setTimePickerVisible(false);
    setEditingTimeId(null);
  };
  
  const handleTimeConfirm = (date: Date) => {
    const newTime = getTimeObject(date);
    
    if (editingTimeId) {
      // Edit existing time
      setTimes(times.map(time => 
        time.id === editingTimeId 
          ? { ...time, hour: date.getHours(), minute: date.getMinutes() } 
          : time
      ));
    } else {
      // Add new time
      setTimes([...times, newTime]);
    }
    
    // Haptic feedback
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    
    hideTimePicker();
  };
  
  const removeTime = (id: string) => {
    setTimes(times.filter(time => time.id !== id));
    
    // Haptic feedback
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };
  
  const handleSave = async () => {
    // Validate inputs
    if (!name.trim()) {
      Alert.alert('Error', 'Please enter a medication name');
      return;
    }
    
    if (!dosage.trim()) {
      Alert.alert('Error', 'Please enter a dosage');
      return;
    }
    
    if (selectedDays.length === 0) {
      Alert.alert('Error', 'Please select at least one day');
      return;
    }
    
    if (times.length === 0) {
      Alert.alert('Error', 'Please add at least one time');
      return;
    }
    
    // Create medication object
    const medication = {
      id: generateId(),
      name: name.trim(),
      dosage: dosage.trim(),
      instructions: instructions.trim(),
      days: selectedDays,
      times,
      color: selectedColor,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    
    try {
      // Save to storage
      const success = await saveMedication(medication);
      
      if (success) {
        // Schedule notifications
        await scheduleMedicationNotifications(medication);
        
        // Haptic feedback
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        
        // Navigate back
        router.back();
      } else {
        Alert.alert('Error', 'Failed to save medication');
      }
    } catch (error) {
      console.error('Error saving medication:', error);
      Alert.alert('Error', 'An unexpected error occurred');
    }
  };
  
  return (
    <ScrollView 
      style={[styles.container, { backgroundColor: colors.background }]}
      keyboardShouldPersistTaps="handled"
    >
      <View style={styles.form}>
        <Text style={[styles.label, { color: colors.text }]}>Medication Name</Text>
        <TextInput
          style={[
            styles.input, 
            { backgroundColor: colors.cardBackground, borderColor: colors.border, color: colors.text }
          ]}
          placeholder="Enter medication name"
          placeholderTextColor={colors.tabIconDefault}
          value={name}
          onChangeText={setName}
        />
        
        <Text style={[styles.label, { color: colors.text }]}>Dosage</Text>
        <TextInput
          style={[
            styles.input, 
            { backgroundColor: colors.cardBackground, borderColor: colors.border, color: colors.text }
          ]}
          placeholder="e.g., 10mg, 1 tablet"
          placeholderTextColor={colors.tabIconDefault}
          value={dosage}
          onChangeText={setDosage}
        />
        
        <Text style={[styles.label, { color: colors.text }]}>Instructions (Optional)</Text>
        <TextInput
          style={[
            styles.textArea, 
            { backgroundColor: colors.cardBackground, borderColor: colors.border, color: colors.text }
          ]}
          placeholder="e.g., Take with food"
          placeholderTextColor={colors.tabIconDefault}
          value={instructions}
          onChangeText={setInstructions}
          multiline
          numberOfLines={3}
          textAlignVertical="top"
        />
        
        <Text style={[styles.label, { color: colors.text }]}>Color</Text>
        <View style={styles.colorOptions}>
          {COLOR_OPTIONS.map(color => (
            <TouchableOpacity
              key={color}
              style={[
                styles.colorOption,
                { backgroundColor: color },
                selectedColor === color && styles.selectedColorOption
              ]}
              onPress={() => setSelectedColor(color)}
            >
              {selectedColor === color && (
                <Check size={16} color="#FFF" />
              )}
            </TouchableOpacity>
          ))}
        </View>
        
        <Text style={[styles.label, { color: colors.text }]}>Schedule Days</Text>
        <View style={styles.daysContainer}>
          {DAYS_OF_WEEK.map(({ label, value }) => (
            <TouchableOpacity
              key={value}
              style={[
                styles.dayButton,
                { 
                  backgroundColor: selectedDays.includes(value) ? colors.tint : colors.pill,
                }
              ]}
              onPress={() => toggleDay(value)}
            >
              <Text
                style={[
                  styles.dayButtonText,
                  { color: selectedDays.includes(value) ? '#FFF' : colors.text }
                ]}
              >
                {label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
        
        <View style={styles.timesHeader}>
          <Text style={[styles.label, { color: colors.text }]}>Schedule Times</Text>
          <TouchableOpacity 
            style={[styles.addTimeButton, { backgroundColor: colors.tint }]}
            onPress={() => showTimePicker()}
          >
            <Plus size={16} color="#FFF" />
            <Text style={styles.addTimeButtonText}>Add Time</Text>
          </TouchableOpacity>
        </View>
        
        {times.length > 0 ? (
          <View style={styles.timesList}>
            {times
              .sort((a, b) => (a.hour * 60 + a.minute) - (b.hour * 60 + b.minute))
              .map(time => (
                <View 
                  key={time.id} 
                  style={[
                    styles.timeItem, 
                    { backgroundColor: colors.cardBackground, borderColor: colors.border }
                  ]}
                >
                  <TouchableOpacity onPress={() => showTimePicker(time.id)}>
                    <Text style={[styles.timeText, { color: colors.text }]}>
                      {formatTime(time.hour, time.minute)}
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => removeTime(time.id)}>
                    <Trash size={20} color={colors.error} />
                  </TouchableOpacity>
                </View>
              ))}
          </View>
        ) : (
          <View style={[styles.emptyTimes, { backgroundColor: colors.pill }]}>
            <Text style={[styles.emptyTimesText, { color: colors.tabIconDefault }]}>
              Tap "Add Time" to set medication times
            </Text>
          </View>
        )}
        
        <TouchableOpacity 
          style={[styles.saveButton, { backgroundColor: colors.tint }]}
          onPress={handleSave}
        >
          <Text style={styles.saveButtonText}>Save Medication</Text>
        </TouchableOpacity>
      </View>
      
      <DateTimePickerModal
        isVisible={isTimePickerVisible}
        mode="time"
        onConfirm={handleTimeConfirm}
        onCancel={hideTimePicker}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  form: {
    padding: 20,
  },
  label: {
    fontSize: 16,
    fontFamily: 'SF-Pro-Text-Medium',
    marginBottom: 8,
  },
  input: {
    height: 48,
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 12,
    marginBottom: 16,
    fontSize: 16,
    fontFamily: 'SF-Pro-Text-Regular',
  },
  textArea: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingTop: 12,
    marginBottom: 16,
    fontSize: 16,
    fontFamily: 'SF-Pro-Text-Regular',
    minHeight: 80,
  },
  colorOptions: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  colorOption: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedColorOption: {
    borderWidth: 2,
    borderColor: '#FFF',
  },
  daysContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 20,
  },
  dayButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
    marginBottom: 8,
  },
  dayButtonText: {
    fontSize: 14,
    fontFamily: 'SF-Pro-Text-Medium',
  },
  timesHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  addTimeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  addTimeButtonText: {
    color: '#FFF',
    marginLeft: 4,
    fontSize: 14,
    fontFamily: 'SF-Pro-Text-Medium',
  },
  timesList: {
    marginBottom: 24,
  },
  timeItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 10,
    marginBottom: 8,
    borderWidth: 1,
  },
  timeText: {
    fontSize: 16,
    fontFamily: 'SF-Pro-Text-Medium',
  },
  emptyTimes: {
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
  },
  emptyTimesText: {
    fontSize: 15,
    fontFamily: 'SF-Pro-Text-Regular',
    textAlign: 'center',
  },
  saveButton: {
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  saveButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontFamily: 'SF-Pro-Display-Semibold',
  },
});