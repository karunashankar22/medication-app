import { useEffect, useState } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useFrameworkReady } from '@/hooks/useFrameworkReady';
import { initStorage } from '@/services/storage';
import { initNotifications } from '@/services/notifications';
import * as SplashScreen from 'expo-splash-screen';
import { useFonts } from 'expo-font';
import { ThemeProvider } from '@/context/ThemeContext';

// Keep the splash screen visible until we're ready
SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  useFrameworkReady();
  const [appIsReady, setAppIsReady] = useState(false);
  
  const [fontsLoaded, fontError] = useFonts({
    'SF-Pro-Display-Bold': require('@/assets/fonts/SF-Pro-Display-Bold.otf'),
    'SF-Pro-Display-Semibold': require('@/assets/fonts/SF-Pro-Display-Semibold.otf'),
    'SF-Pro-Text-Regular': require('@/assets/fonts/SF-Pro-Text-Regular.otf'),
    'SF-Pro-Text-Medium': require('@/assets/fonts/SF-Pro-Text-Medium.otf'),
  });

  useEffect(() => {
    async function prepare() {
      try {
        // Initialize storage
        await initStorage();
        
        // Initialize notifications
        await initNotifications();
      } catch (e) {
        console.warn('Error preparing app:', e);
      } finally {
        setAppIsReady(true);
      }
    }

    prepare();
  }, []);

  useEffect(() => {
    if ((appIsReady && fontsLoaded) || fontError) {
      SplashScreen.hideAsync();
    }
  }, [appIsReady, fontsLoaded, fontError]);

  if (!appIsReady || (!fontsLoaded && !fontError)) {
    return null;
  }

  return (
    <ThemeProvider>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="medication/[id]" options={{ presentation: 'modal', headerShown: true, title: 'Medication Details' }} />
        <Stack.Screen name="medication/add" options={{ presentation: 'modal', headerShown: true, title: 'Add Medication' }} />
        <Stack.Screen name="medication/edit/[id]" options={{ presentation: 'modal', headerShown: true, title: 'Edit Medication' }} />
        <Stack.Screen name="+not-found" options={{ title: 'Not Found' }} />
      </Stack>
      <StatusBar style="auto" />
    </ThemeProvider>
  );
}